/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;

public class Registration {
    public static void main(String[] args) {
        Login login = new Login();

        // Registration Process
        JOptionPane.showMessageDialog(null, "Register..........");
        login.firstName = JOptionPane.showInputDialog("Enter First Name:");
        login.surname = JOptionPane.showInputDialog("Enter Last Name:");
        login.userName = JOptionPane.showInputDialog("Enter Username:");
        login.password = JOptionPane.showInputDialog("Enter Password:");
        login.cellPhone = JOptionPane.showInputDialog("Enter Cellphone Number:");
        JOptionPane.showMessageDialog(null, login.registerUser());

        while (!login.checkUsername() || !login.checkPasswordComplexity()) {
            JOptionPane.showMessageDialog(null, "Try to register again!!!!!");
            login.userName = JOptionPane.showInputDialog("Enter Username:");
            login.password = JOptionPane.showInputDialog("Enter Password:");
            login.cellPhone = JOptionPane.showInputDialog("Enter Cellphone Number:");
            JOptionPane.showMessageDialog(null, login.registerUser());
        }

        // Login Process
        JOptionPane.showMessageDialog(null, "Login..........");
        login.enteredUserName = JOptionPane.showInputDialog("Enter Username:");
        login.enteredPassword = JOptionPane.showInputDialog("Enter Password:");
        login.enteredCell = JOptionPane.showInputDialog("Enter Cellphone Number:");
        JOptionPane.showMessageDialog(null, login.returnLoginStatus());

        while (!login.loginUser()) {
            JOptionPane.showMessageDialog(null, "Try to Login again ..........");
            login.enteredUserName = JOptionPane.showInputDialog("Enter Username:");
            login.enteredPassword = JOptionPane.showInputDialog("Enter Password:");
            login.enteredCell = JOptionPane.showInputDialog("Enter Cellphone Number:");
            JOptionPane.showMessageDialog(null, login.returnLoginStatus());
        }

        // Messaging Menu
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        int messageLimit = Integer.parseInt(JOptionPane.showInputDialog("Enter how many messages you want to send:"));
        int sent = 0;

        while (true) {
            String[] options = {"Send Message", "Show Sent Messages", "Coming Soon", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            if (choice == 0 && sent < messageLimit) {
                String recipient = JOptionPane.showInputDialog("Enter recipient number (start with +):");
                String message = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
                String result = Message.createMessage(recipient, message);
                if (result.contains("successfully")) {
                    sent++;
                } else {
                    JOptionPane.showMessageDialog(null, result);
                }
            } else if (choice == 1) {
                Message.printAllMessages();
            } else if (choice == 2) {
                JOptionPane.showMessageDialog(null, "Coming Soon.");
            } else if (choice == 3) {
                JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.getTotalMessages());
                break;
            } else if (sent >= messageLimit) {
                JOptionPane.showMessageDialog(null, "You have reached the message limit.");
            }
        }
    }
}