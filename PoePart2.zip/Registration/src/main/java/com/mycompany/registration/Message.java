/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;
import java.util.*;
import java.io.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

public class Message {
    private static int totalMessages = 0;
    private static long messageCounter = 1000000000L;
    private static final ArrayList<MessageModel> sentMessages = new ArrayList<>();
    private static final String FILE_PATH = "messages.json";

    public static String createMessage(String recipient, String content) {
        if (recipient.length() > 10 || !recipient.startsWith("+")) {
            return "Invalid recipient number.";
        }

        if (content.length() > 250) {
            return "Please enter a message of less than 250 characters.";
        }

        long messageId = messageCounter++;
        String hash = generateHash(messageId, content);
        MessageModel msg = new MessageModel(messageId, hash, recipient, content);

        String fullMessage = "Message ID: " + messageId +
                             "\nMessage Hash: " + hash +
                             "\nRecipient: " + recipient +
                             "\nMessage: " + content;

        int choice = JOptionPane.showConfirmDialog(null, fullMessage + "\nSend this message?", "Send Message",
                                                   JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            sentMessages.add(msg);
            storeMessageToJSON();
            totalMessages++;
            JOptionPane.showMessageDialog(null, fullMessage, "Message Sent", JOptionPane.INFORMATION_MESSAGE);
            return "Message sent successfully.";
        } else {
            return "Message not sent.";
        }
    }

    public static String generateHash(long id, String content) {
        String[] words = content.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        return (String.valueOf(id).substring(0, 2) + ":" + totalMessages + ":" + firstWord + lastWord).toUpperCase();
    }

    public static void printAllMessages() {
        ArrayList<MessageModel> allMessages = readMessagesFromJSON();
        if (allMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
        } else {
            for (MessageModel m : allMessages) {
                String info = "Message ID: " + m.messageId +
                              "\nMessage Hash: " + m.messageHash +
                              "\nRecipient: " + m.recipient +
                              "\nMessage: " + m.content;
                JOptionPane.showMessageDialog(null, info, "Stored Message", JOptionPane.INFORMATION_MESSAGE);
            }
        }
    }

    private static void storeMessageToJSON() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            List<MessageModel> current = readMessagesFromJSON();
            current.addAll(sentMessages);
            mapper.writeValue(new File(FILE_PATH), current);
            sentMessages.clear();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Failed to save messages to JSON: " + e.getMessage());
        }
    }

    private static ArrayList<MessageModel> readMessagesFromJSON() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            File file = new File(FILE_PATH);
            if (!file.exists()) return new ArrayList<>();
            return mapper.readValue(file, new TypeReference<ArrayList<MessageModel>>() {});
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public static int getTotalMessages() {
        return totalMessages;
    }
}